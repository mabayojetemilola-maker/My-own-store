"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { Product } from "@/types";
import { sampleProducts } from "@/lib/products";
import { collection, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { ArrowRight, Dumbbell, Truck, Shield, Star } from "lucide-react";

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadProducts() {
      try {
        const snap = await getDocs(collection(db, "products"));
        if (snap.empty) {
          const withIds = sampleProducts.map((p, i) => ({
            ...p,
            id: `sample-${i}`,
          }));
          setProducts(withIds);
        } else {
          const data = snap.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })) as Product[];
          setProducts(data);
        }
      } catch (err) {
        console.error(err);
        const withIds = sampleProducts.map((p, i) => ({
          ...p,
          id: `sample-${i}`,
        }));
        setProducts(withIds);
      } finally {
        setLoading(false);
      }
    }
    loadProducts();
  }, []);

  const featured = products.filter((p) => p.featured).slice(0, 4);
  const display = featured.length > 0 ? featured : products.slice(0, 4);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-yellow-400 via-yellow-300 to-yellow-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              Level Up Your{" "}
              <span className="text-black">Calisthenics</span> Game
            </h1>
            <p className="text-lg text-gray-800 mb-8">
              Premium parallettes, parallel bars, resistance bands and
              accessories. Built for athletes who take training seriously.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link
                href="/shop"
                className="bg-black text-white px-8 py-3.5 rounded-lg font-semibold hover:bg-gray-800 transition flex items-center gap-2"
              >
                Shop Now <ArrowRight size={18} />
              </Link>
              <Link
                href="/shop"
                className="bg-white text-black px-8 py-3.5 rounded-lg font-semibold hover:bg-gray-100 transition border border-black/10"
              >
                View All Products
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-12 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: <Dumbbell className="text-yellow-500" size={28} />,
                title: "Premium Quality",
                desc: "Durable materials built to last",
              },
              {
                icon: <Truck className="text-yellow-500" size={28} />,
                title: "Fast Delivery",
                desc: "Nationwide shipping available",
              },
              {
                icon: <Shield className="text-yellow-500" size={28} />,
                title: "Secure Payment",
                desc: "Paystack ready checkout",
              },
              {
                icon: <Star className="text-yellow-500" size={28} />,
                title: "Athlete Approved",
                desc: "Trusted by calisthenics community",
              },
            ].map((f) => (
              <div
                key={f.title}
                className="flex items-start gap-4 p-4 rounded-xl bg-gray-50"
              >
                <div className="shrink-0">{f.icon}</div>
                <div>
                  <h3 className="font-semibold text-gray-900">{f.title}</h3>
                  <p className="text-sm text-gray-500">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-3xl font-bold text-gray-900">
                Featured Products
              </h2>
              <p className="text-gray-500 mt-1">
                Our most popular calisthenics equipment
              </p>
            </div>
            <Link
              href="/shop"
              className="hidden sm:flex items-center gap-1 text-yellow-600 font-medium hover:text-yellow-700"
            >
              View all <ArrowRight size={16} />
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className="bg-gray-100 rounded-xl aspect-[3/4] animate-pulse"
                />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {display.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <div className="mt-10 text-center sm:hidden">
            <Link
              href="/shop"
              className="inline-flex items-center gap-2 bg-yellow-400 text-black px-6 py-3 rounded-lg font-semibold"
            >
              View All Products <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gray-900 py-16">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Train Like a Pro?
          </h2>
          <p className="text-gray-400 mb-8">
            Browse our full collection of parallettes, bars, bands and more.
          </p>
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 bg-yellow-400 text-black px-8 py-3.5 rounded-lg font-semibold hover:bg-yellow-300 transition"
          >
            Explore Shop <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
}
