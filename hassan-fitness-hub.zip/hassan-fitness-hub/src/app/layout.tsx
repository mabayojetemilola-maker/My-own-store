import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/context/CartContext";
import Navbar from "@/components/Navbar";
import { Toaster } from "react-hot-toast";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Hassan Fitness Hub | Calisthenics Equipment",
  description:
    "Premium parallettes, parallel bars, resistance bands and calisthenics gear. Shop quality fitness equipment in Nigeria.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} min-h-screen flex flex-col antialiased bg-white`}
      >
        <CartProvider>
          <Navbar />
          <main className="flex-1">{children}</main>
          <footer className="bg-gray-900 text-white py-10 mt-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <div className="w-9 h-9 bg-yellow-400 rounded-lg flex items-center justify-center font-bold text-black">
                      H
                    </div>
                    <span className="font-bold text-lg">Hassan Fitness Hub</span>
                  </div>
                  <p className="text-gray-400 text-sm">
                    Premium calisthenics and fitness equipment for athletes in
                    Nigeria and beyond.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">Quick Links</h4>
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li>
                      <a href="/" className="hover:text-yellow-400">
                        Home
                      </a>
                    </li>
                    <li>
                      <a href="/shop" className="hover:text-yellow-400">
                        Shop
                      </a>
                    </li>
                    <li>
                      <a href="/cart" className="hover:text-yellow-400">
                        Cart
                      </a>
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">Contact</h4>
                  <p className="text-sm text-gray-400">
                    Email: mabayojetemilola@gmail.com
                  </p>
                  <p className="text-sm text-gray-400 mt-1">
                    Built with love for fitness enthusiasts
                  </p>
                </div>
              </div>
              <div className="border-t border-gray-800 mt-8 pt-6 text-center text-sm text-gray-500">
                © {new Date().getFullYear()} Hassan Fitness Hub. All rights
                reserved.
              </div>
            </div>
          </footer>
          <Toaster position="bottom-right" />
        </CartProvider>
      </body>
    </html>
  );
}
