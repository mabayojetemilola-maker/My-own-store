"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  onAuthStateChanged,
  signOut,
  User,
} from "firebase/auth";
import {
  collection,
  getDocs,
  addDoc,
  deleteDoc,
  doc,
  updateDoc,
  serverTimestamp,
} from "firebase/firestore";
import { auth, db } from "@/lib/firebase";
import { Product, Order } from "@/types";
import { sampleProducts } from "@/lib/products";
import toast from "react-hot-toast";
import {
  LogOut,
  Plus,
  Trash2,
  Package,
  ShoppingBag,
  X,
} from "lucide-react";
import Link from "next/link";

const ADMIN_EMAIL = "mabayojetemilola@gmail.com";

export default function AdminDashboard() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<"products" | "orders">("products");
  const [showAddModal, setShowAddModal] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const router = useRouter();

  const [newProduct, setNewProduct] = useState({
    name: "",
    description: "",
    price: "",
    image: "",
    category: "Parallettes",
    stock: "10",
    featured: false,
  });

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      if (!u || u.email?.toLowerCase() !== ADMIN_EMAIL.toLowerCase()) {
        router.push("/admin/login");
        return;
      }
      setUser(u);
      setLoading(false);
      loadData();
    });
    return () => unsub();
  }, [router]);

  async function loadData() {
    try {
      const [prodSnap, orderSnap] = await Promise.all([
        getDocs(collection(db, "products")),
        getDocs(collection(db, "orders")),
      ]);

      setProducts(
        prodSnap.docs.map((d) => ({ id: d.id, ...d.data() })) as Product[]
      );
      setOrders(
        orderSnap.docs.map((d) => ({
          id: d.id,
          ...d.data(),
        })) as Order[]
      );
    } catch (err) {
      console.error(err);
      toast.error("Failed to load data");
    }
  }

  const handleLogout = async () => {
    await signOut(auth);
    router.push("/admin/login");
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, "products"), {
        name: newProduct.name,
        description: newProduct.description,
        price: Number(newProduct.price),
        image: newProduct.image || "https://via.placeholder.com/400",
        category: newProduct.category,
        stock: Number(newProduct.stock),
        featured: newProduct.featured,
        createdAt: serverTimestamp(),
      });
      toast.success("Product added!");
      setShowAddModal(false);
      setNewProduct({
        name: "",
        description: "",
        price: "",
        image: "",
        category: "Parallettes",
        stock: "10",
        featured: false,
      });
      loadData();
    } catch (err) {
      console.error(err);
      toast.error("Failed to add product");
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm("Delete this product?")) return;
    try {
      await deleteDoc(doc(db, "products", id));
      toast.success("Product deleted");
      loadData();
    } catch {
      toast.error("Failed to delete");
    }
  };

  const handleSeedProducts = async () => {
    if (!confirm("This will add all sample products to Firestore. Continue?"))
      return;
    setSeeding(true);
    try {
      for (const p of sampleProducts) {
        await addDoc(collection(db, "products"), {
          ...p,
          createdAt: serverTimestamp(),
        });
      }
      toast.success("Sample products added successfully!");
      loadData();
    } catch (err) {
      console.error(err);
      toast.error("Seeding failed");
    } finally {
      setSeeding(false);
    }
  };

  const updateOrderStatus = async (orderId: string, status: string) => {
    try {
      await updateDoc(doc(db, "orders", orderId), { status });
      toast.success("Order updated");
      loadData();
    } catch {
      toast.error("Update failed");
    }
  };

  const formatPrice = (price: number) =>
    new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      minimumFractionDigits: 0,
    }).format(price);

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-yellow-400 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-sm text-gray-500">{user?.email}</p>
        </div>
        <div className="flex items-center gap-3">
          <Link
            href="/"
            className="text-sm text-gray-500 hover:text-yellow-600"
          >
            View Store
          </Link>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 text-sm text-red-600 hover:text-red-700 font-medium"
          >
            <LogOut size={16} /> Logout
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm">
          <div className="flex items-center gap-3">
            <Package className="text-yellow-500" size={24} />
            <div>
              <p className="text-2xl font-bold">{products.length}</p>
              <p className="text-xs text-gray-500">Products</p>
            </div>
          </div>
        </div>
        <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm">
          <div className="flex items-center gap-3">
            <ShoppingBag className="text-yellow-500" size={24} />
            <div>
              <p className="text-2xl font-bold">{orders.length}</p>
              <p className="text-xs text-gray-500">Orders</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-gray-100">
        <button
          onClick={() => setActiveTab("products")}
          className={`px-4 py-2.5 text-sm font-medium border-b-2 transition ${
            activeTab === "products"
              ? "border-yellow-400 text-yellow-700"
              : "border-transparent text-gray-500"
          }`}
        >
          Products
        </button>
        <button
          onClick={() => setActiveTab("orders")}
          className={`px-4 py-2.5 text-sm font-medium border-b-2 transition ${
            activeTab === "orders"
              ? "border-yellow-400 text-yellow-700"
              : "border-transparent text-gray-500"
          }`}
        >
          Orders
        </button>
      </div>

      {/* Products Tab */}
      {activeTab === "products" && (
        <div>
          <div className="flex flex-wrap gap-3 mb-6">
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 bg-yellow-400 hover:bg-yellow-500 text-black font-medium px-4 py-2 rounded-lg text-sm"
            >
              <Plus size={16} /> Add Product
            </button>
            {products.length === 0 && (
              <button
                onClick={handleSeedProducts}
                disabled={seeding}
                className="flex items-center gap-2 bg-gray-900 hover:bg-gray-800 text-white font-medium px-4 py-2 rounded-lg text-sm disabled:opacity-60"
              >
                {seeding ? "Seeding..." : "Seed Sample Products"}
              </button>
            )}
          </div>

          {products.length === 0 ? (
            <div className="text-center py-16 bg-gray-50 rounded-xl">
              <p className="text-gray-500 mb-4">No products yet</p>
              <button
                onClick={handleSeedProducts}
                disabled={seeding}
                className="bg-yellow-400 text-black px-5 py-2 rounded-lg font-medium text-sm"
              >
                {seeding ? "Adding..." : "Add Sample Products"}
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-gray-500">
                    <th className="pb-3 pr-4">Product</th>
                    <th className="pb-3 pr-4">Category</th>
                    <th className="pb-3 pr-4">Price</th>
                    <th className="pb-3 pr-4">Stock</th>
                    <th className="pb-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((p) => (
                    <tr key={p.id} className="border-b border-gray-50">
                      <td className="py-3 pr-4">
                        <div className="font-medium text-gray-900">{p.name}</div>
                      </td>
                      <td className="py-3 pr-4 text-gray-500">{p.category}</td>
                      <td className="py-3 pr-4 font-medium">
                        {formatPrice(p.price)}
                      </td>
                      <td className="py-3 pr-4">{p.stock}</td>
                      <td className="py-3">
                        <button
                          onClick={() => handleDeleteProduct(p.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Orders Tab */}
      {activeTab === "orders" && (
        <div>
          {orders.length === 0 ? (
            <div className="text-center py-16 bg-gray-50 rounded-xl">
              <p className="text-gray-500">No orders yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <div
                  key={order.id}
                  className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                    <div>
                      <p className="font-semibold text-gray-900">
                        {order.customerName}
                      </p>
                      <p className="text-sm text-gray-500">
                        {order.customerEmail} · {order.customerPhone}
                      </p>
                      <p className="text-sm text-gray-500 mt-1">
                        {order.address}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg">
                        {formatPrice(order.total)}
                      </p>
                      <select
                        value={order.status}
                        onChange={(e) =>
                          updateOrderStatus(order.id!, e.target.value)
                        }
                        className="mt-1 text-sm border border-gray-200 rounded-lg px-2 py-1"
                      >
                        <option value="pending">Pending</option>
                        <option value="processing">Processing</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600 border-t pt-3">
                    {order.items?.map((item, i) => (
                      <div key={i}>
                        {item.name} × {item.quantity}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold">Add New Product</h2>
              <button onClick={() => setShowAddModal(false)}>
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleAddProduct} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name *</label>
                <input
                  required
                  value={newProduct.name}
                  onChange={(e) =>
                    setNewProduct({ ...newProduct, name: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">
                  Description *
                </label>
                <textarea
                  required
                  rows={3}
                  value={newProduct.description}
                  onChange={(e) =>
                    setNewProduct({
                      ...newProduct,
                      description: e.target.value,
                    })
                  }
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Price (₦) *
                  </label>
                  <input
                    required
                    type="number"
                    value={newProduct.price}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, price: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Stock *
                  </label>
                  <input
                    required
                    type="number"
                    value={newProduct.stock}
                    onChange={(e) =>
                      setNewProduct({ ...newProduct, stock: e.target.value })
                    }
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">
                  Category
                </label>
                <select
                  value={newProduct.category}
                  onChange={(e) =>
                    setNewProduct({ ...newProduct, category: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
                >
                  <option>Parallettes</option>
                  <option>Parallel Bars</option>
                  <option>Bands</option>
                  <option>Accessories</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">
                  Image URL
                </label>
                <input
                  value={newProduct.image}
                  onChange={(e) =>
                    setNewProduct({ ...newProduct, image: e.target.value })
                  }
                  placeholder="https://..."
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
              </div>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={newProduct.featured}
                  onChange={(e) =>
                    setNewProduct({
                      ...newProduct,
                      featured: e.target.checked,
                    })
                  }
                />
                Featured product
              </label>

              <button
                type="submit"
                className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-semibold py-3 rounded-lg"
              >
                Add Product
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
