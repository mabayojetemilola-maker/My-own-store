"use client";

import Link from "next/link";
import { useCart } from "@/context/CartContext";
import { ShoppingCart, Menu, X, Search } from "lucide-react";
import { useState } from "react";

export default function Navbar() {
  const { cartCount } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="bg-white border-b border-yellow-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-yellow-400 rounded-lg flex items-center justify-center font-bold text-black text-xl">
              H
            </div>
            <span className="font-bold text-xl text-gray-900 hidden sm:block">
              Hassan Fitness Hub
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <Link
              href="/"
              className="text-gray-700 hover:text-yellow-600 font-medium transition"
            >
              Home
            </Link>
            <Link
              href="/shop"
              className="text-gray-700 hover:text-yellow-600 font-medium transition"
            >
              Shop
            </Link>
            <Link
              href="/cart"
              className="relative text-gray-700 hover:text-yellow-600 font-medium transition flex items-center gap-1"
            >
              <ShoppingCart size={20} />
              Cart
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-4 bg-yellow-400 text-black text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
            <Link
              href="/admin"
              className="text-sm text-gray-500 hover:text-yellow-600 transition"
            >
              Admin
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-white border-t border-yellow-100 px-4 py-4 space-y-3">
          <Link
            href="/"
            className="block py-2 text-gray-700 font-medium"
            onClick={() => setMobileOpen(false)}
          >
            Home
          </Link>
          <Link
            href="/shop"
            className="block py-2 text-gray-700 font-medium"
            onClick={() => setMobileOpen(false)}
          >
            Shop
          </Link>
          <Link
            href="/cart"
            className="block py-2 text-gray-700 font-medium flex items-center gap-2"
            onClick={() => setMobileOpen(false)}
          >
            <ShoppingCart size={18} />
            Cart ({cartCount})
          </Link>
          <Link
            href="/admin"
            className="block py-2 text-gray-500 text-sm"
            onClick={() => setMobileOpen(false)}
          >
            Admin
          </Link>
        </div>
      )}
    </nav>
  );
}
