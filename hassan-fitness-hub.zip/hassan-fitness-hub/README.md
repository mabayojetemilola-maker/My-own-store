# Hassan Fitness Hub

Premium calisthenics & fitness equipment e-commerce store built with **Next.js + Firebase**.

## Features

- Home page with featured products
- Shop page with **Search** + **Price Range** + Category filters
- Add to Cart (localStorage persistent)
- Checkout & Order placement (saved to Firestore)
- Admin Dashboard (restricted to one email)
  - Add / Delete products
  - View & update orders
  - One-click seed sample products
- White + Yellow theme
- Fully dynamic (not static)
- Ready for Paystack integration later

## Admin Access

Only this account can access `/admin`:

- **Email:** `mabayojetemilola@gmail.com`
- **Password:** `Temilola@1`

You must create this user in Firebase Authentication first.

## Setup Instructions

### 1. Firebase Setup

1. Go to [Firebase Console](https://console.firebase.google.com/) → project `hassan-fitness-hub`
2. Enable **Authentication** → Sign-in method → **Email/Password**
3. Create the admin user:
   - Authentication → Users → Add user
   - Email: `mabayojetemilola@gmail.com`
   - Password: `Temilola@1`
4. Enable **Firestore Database**
   - Create database (start in test mode for easy development)
5. (Optional) Enable **Storage** for product images

### 2. Firestore Security Rules (recommended for production)

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /products/{doc} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.token.email == 'mabayojetemilola@gmail.com';
    }
    match /orders/{doc} {
      allow create: if true;
      allow read, update: if request.auth != null && request.auth.token.email == 'mabayojetemilola@gmail.com';
    }
  }
}
```

### 3. Local Development

```bash
cd hassan-fitness-hub
npm install
npm run dev
```

Open http://localhost:3000

### 4. Seed Products

1. Go to `/admin/login`
2. Login with the admin credentials
3. Click **"Seed Sample Products"**

### 5. Deploy to Vercel + GitHub

1. Push this folder to a GitHub repository
2. Go to [vercel.com](https://vercel.com) → New Project → Import the repo
3. Deploy (no extra environment variables needed)
4. Your site will be live!

## Project Structure

```
src/
  app/
    page.tsx          → Home
    shop/page.tsx     → Shop + filters
    cart/page.tsx     → Cart
    checkout/page.tsx → Checkout
    admin/
      login/page.tsx  → Admin login
      page.tsx        → Admin dashboard
  components/
    Navbar.tsx
    ProductCard.tsx
  context/
    CartContext.tsx
  lib/
    firebase.ts
    products.ts       → Sample product data
  types/
    index.ts
```

## Notes

- Product images currently use Unsplash placeholders. Replace them via Admin panel or Firebase Storage.
- Cart is stored in browser localStorage.
- Orders are stored in Firestore collection `orders`.
- Paystack can be added later in the checkout page.
